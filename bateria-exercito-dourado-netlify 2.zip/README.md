# Bateria Exército Dourado — aplicativo

Primeira versão: cadastro de ritmistas, tamanhos de camiseta/fantasia, calçado, instrumento, presença, busca, edição, exclusão e exportação CSV.

## Publicar no Netlify
1. Acesse sua conta do Netlify.
2. Crie um novo site e faça upload da pasta/ZIP.
3. O Netlify fornecerá um endereço `*.netlify.app`.

Observação: esta primeira versão salva os dados no navegador (localStorage). Para vários diretores usarem o mesmo cadastro em celulares diferentes, a próxima etapa deve adicionar um banco de dados e login.
